/* global React */

// ────────────────────────────────────────────────────────────────────────────
// Shared primitives for Rosie
// ────────────────────────────────────────────────────────────────────────────

// Tiny ornamental marks used throughout. Drawn as SVG so they scale and tint.
const Ornament = ({ kind = 'dot', size = 16, color = 'currentColor', style }) => {
  const s = { width: size, height: size, color, display: 'inline-block', verticalAlign: 'middle', ...style };
  if (kind === 'dot') {
    return (
      <svg viewBox="0 0 16 16" style={s} aria-hidden="true">
        <circle cx="8" cy="8" r="1.4" fill="currentColor" />
      </svg>
    );
  }
  if (kind === 'asterism') {
    return (
      <svg viewBox="0 0 32 16" style={{ ...s, width: size * 2 }} aria-hidden="true">
        <circle cx="6"  cy="8" r="1.1" fill="currentColor" />
        <circle cx="16" cy="8" r="1.1" fill="currentColor" />
        <circle cx="26" cy="8" r="1.1" fill="currentColor" />
      </svg>
    );
  }
  if (kind === 'sprig') {
    // Tiny botanical sprig — used near brand mark
    return (
      <svg viewBox="0 0 24 24" style={s} aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round">
        <path d="M12 22 V6" />
        <path d="M12 9 Q7 8 5 4.5" />
        <path d="M12 13 Q17 12 19 8.5" />
        <path d="M12 17 Q8 16 6.5 13" />
        <circle cx="12" cy="5" r="1.4" fill="currentColor" stroke="none" opacity=".55" />
      </svg>
    );
  }
  if (kind === 'rose') {
    // Abstract rose mark for the Rosie brand
    return (
      <svg viewBox="0 0 24 24" style={s} aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="9" opacity=".25" />
        <path d="M12 7c-2.2 0-3.6 1.4-3.6 3 0 1.3 1 2.2 2.4 2.2 1 0 1.8-.6 1.8-1.4 0-.6-.4-1-1-1" />
        <path d="M12 10.5c1.4 0 2.4.9 2.4 2.1 0 1.5-1.5 2.9-3.6 2.9" />
        <path d="M9 16.5c1.6.6 4.5.6 6.5-.8" opacity=".65" />
      </svg>
    );
  }
  if (kind === 'leaf') {
    return (
      <svg viewBox="0 0 24 24" style={s} aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round">
        <path d="M4 20c6 0 16-6 16-16-6 0-16 6-16 16Z" />
        <path d="M4 20 14 10" />
      </svg>
    );
  }
  return null;
};

// Painterly placeholder tile — used for vendor cards, mood-board photos, and
// any "needs a real photograph" slot. Looks intentional, not stocky.
const PaperTile = ({ tone = 'rose', label, kind = 'florals', style, children }) => {
  const tones = {
    rose: { bg: 'linear-gradient(135deg, var(--rose-tint), var(--rose-soft))', ink: 'var(--rose-ink)' },
    sage: { bg: 'linear-gradient(135deg, var(--sage-tint), var(--sage-soft))', ink: 'var(--sage-ink)' },
    blue: { bg: 'linear-gradient(135deg, var(--blue-tint), var(--blue-soft))', ink: 'var(--blue-ink)' },
    cream:{ bg: 'linear-gradient(135deg, #f3ebdc, #e8dec7)',                    ink: 'var(--ink-2)' },
  };
  const t = tones[tone] || tones.rose;
  return (
    <div className="paper-tile" style={{ background: t.bg, color: t.ink, ...style }}>
      <PaperArt kind={kind} />
      {label && <span className="paper-tile__label">{label}</span>}
      {children}
    </div>
  );
};

// Small botanical/abstract illustrations drawn into PaperTile.
const PaperArt = ({ kind }) => {
  const stroke = 'currentColor';
  const common = { fill: 'none', stroke, strokeWidth: 0.7, strokeLinecap: 'round', strokeLinejoin: 'round' };
  if (kind === 'florals' || kind === 'bouquet') {
    return (
      <svg className="paper-tile__art" viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g opacity=".55" {...common}>
          <path d="M100 130 V70" />
          <path d="M100 88 Q72 80 60 56" />
          <path d="M100 100 Q132 90 144 64" />
          <path d="M100 112 Q78 108 66 90" />
          <circle cx="60" cy="56" r="9" />
          <circle cx="144" cy="64" r="11" />
          <circle cx="66" cy="90" r="7" />
          <circle cx="100" cy="70" r="14" />
          <circle cx="100" cy="70" r="6" />
          <path d="M88 56 Q92 50 100 50 Q108 50 112 56" />
        </g>
      </svg>
    );
  }
  if (kind === 'place') {
    return (
      <svg className="paper-tile__art" viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g opacity=".55" {...common}>
          <circle cx="100" cy="74" r="46" />
          <circle cx="100" cy="74" r="34" />
          <rect x="64" y="68" width="14" height="42" rx="1" />
          <rect x="122" y="68" width="14" height="42" rx="1" />
          <path d="M96 56 Q100 50 104 56" />
        </g>
      </svg>
    );
  }
  if (kind === 'candles') {
    return (
      <svg className="paper-tile__art" viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g opacity=".6" {...common}>
          <path d="M60 130 V70" />
          <path d="M84 130 V58" />
          <path d="M108 130 V64" />
          <path d="M132 130 V52" />
          <path d="M156 130 V68" />
          <path d="M60 68 Q58 64 60 60 Q62 64 60 60" />
          <ellipse cx="60" cy="62" rx="3" ry="6" />
          <ellipse cx="84" cy="50" rx="3" ry="6" />
          <ellipse cx="108" cy="56" rx="3" ry="6" />
          <ellipse cx="132" cy="44" rx="3" ry="6" />
          <ellipse cx="156" cy="60" rx="3" ry="6" />
        </g>
      </svg>
    );
  }
  if (kind === 'cake') {
    return (
      <svg className="paper-tile__art" viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g opacity=".55" {...common}>
          <rect x="80"  y="38" width="40" height="22" rx="1" />
          <rect x="68"  y="60" width="64" height="26" rx="1" />
          <rect x="56"  y="86" width="88" height="30" rx="1" />
          <path d="M80 38 Q100 30 120 38" />
          <path d="M88 38 V32" />
          <path d="M100 38 V28" />
          <path d="M112 38 V32" />
        </g>
      </svg>
    );
  }
  if (kind === 'stationery') {
    return (
      <svg className="paper-tile__art" viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g opacity=".55" {...common}>
          <rect x="50" y="38" width="100" height="68" rx="1" transform="rotate(-4 100 72)" />
          <path d="M70 64 H130" transform="rotate(-4 100 72)" />
          <path d="M70 76 H120" transform="rotate(-4 100 72)" />
          <path d="M70 88 H114" transform="rotate(-4 100 72)" />
          <text x="100" y="58" textAnchor="middle" fontFamily="Cormorant Garamond, serif" fontStyle="italic" fontSize="14" fill="currentColor" stroke="none" opacity=".7" transform="rotate(-4 100 72)">k &amp; h</text>
        </g>
      </svg>
    );
  }
  if (kind === 'arch' || kind === 'venue') {
    return (
      <svg className="paper-tile__art" viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g opacity=".55" {...common}>
          <path d="M40 120 V70 Q40 30 100 30 Q160 30 160 70 V120" />
          <path d="M40 70 Q60 50 100 50 Q140 50 160 70" />
          <circle cx="60" cy="58" r="6" />
          <circle cx="80" cy="46" r="7" />
          <circle cx="120" cy="46" r="6" />
          <circle cx="140" cy="58" r="5" />
        </g>
      </svg>
    );
  }
  if (kind === 'rings') {
    return (
      <svg className="paper-tile__art" viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g opacity=".6" {...common}>
          <circle cx="86" cy="72" r="28" />
          <circle cx="114" cy="72" r="28" />
        </g>
      </svg>
    );
  }
  if (kind === 'silk') {
    return (
      <svg className="paper-tile__art" viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g opacity=".55" {...common}>
          <path d="M30 30 Q70 80 50 130" />
          <path d="M70 20 Q120 70 100 130" />
          <path d="M110 30 Q150 70 140 130" />
          <path d="M150 24 Q190 80 180 130" />
        </g>
      </svg>
    );
  }
  if (kind === 'dress') {
    return (
      <svg className="paper-tile__art" viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g opacity=".55" {...common}>
          <path d="M90 40 H110 L120 70 L140 130 H60 L80 70 Z" />
          <path d="M100 40 V130" />
          <path d="M86 80 H114" />
        </g>
      </svg>
    );
  }
  if (kind === 'bar') {
    return (
      <svg className="paper-tile__art" viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g opacity=".55" {...common}>
          <path d="M60 50 H100 L84 80 V120 H76 V120" />
          <path d="M80 90 H92" />
          <path d="M110 50 H150 L134 80 V120 H126" />
          <path d="M130 90 H142" />
        </g>
      </svg>
    );
  }
  if (kind === 'music') {
    return (
      <svg className="paper-tile__art" viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g opacity=".55" {...common}>
          <circle cx="76" cy="96" r="12" />
          <circle cx="132" cy="86" r="12" />
          <path d="M88 96 V40 L144 30 V86" />
        </g>
      </svg>
    );
  }
  if (kind === 'car') {
    return (
      <svg className="paper-tile__art" viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g opacity=".55" {...common}>
          <path d="M40 100 H160 V80 L140 60 H70 L50 80 Z" />
          <circle cx="68" cy="106" r="10" />
          <circle cx="138" cy="106" r="10" />
          <path d="M76 60 V80 H124 V60" />
        </g>
      </svg>
    );
  }
  if (kind === 'monogram') {
    return (
      <svg className="paper-tile__art" viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <text x="100" y="92" textAnchor="middle" fontFamily="Cormorant Garamond, serif"
              fontStyle="italic" fontWeight="400" fontSize="64" fill="currentColor" opacity=".5">k &amp; h</text>
      </svg>
    );
  }
  return null;
};

// Section title — "smallcaps" letterspaced label with hairline rule beside it.
const SectionLabel = ({ children, style, align = 'left' }) => (
  <div className={`section-label section-label--${align}`} style={style}>
    <span>{children}</span>
  </div>
);

// Numeric KPI / stat
const Stat = ({ label, value, hint, accent }) => (
  <div className="stat">
    <div className="stat__value" style={accent ? { color: `var(--${accent})` } : null}>{value}</div>
    <div className="stat__label">{label}</div>
    {hint && <div className="stat__hint">{hint}</div>}
  </div>
);

// Pill / status chip used in vendor lists and elsewhere
const Pill = ({ tone = 'neutral', children, dot = true }) => (
  <span className={`pill pill--${tone}`}>
    {dot && <i className="pill__dot" />}
    {children}
  </span>
);

// Currency formatter — no cents, narrow space
const fmtMoney = (n) => '$' + n.toLocaleString('en-US');
const fmtMoneyShort = (n) => {
  if (n >= 1000) return '$' + (n / 1000).toFixed(n % 1000 === 0 ? 0 : 1) + 'k';
  return '$' + n;
};

Object.assign(window, {
  Ornament, PaperTile, PaperArt, SectionLabel, Stat, Pill, fmtMoney, fmtMoneyShort,
});
