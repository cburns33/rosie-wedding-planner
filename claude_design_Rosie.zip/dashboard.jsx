/* global React, RosieData, Ornament, PaperTile, SectionLabel, Stat, Pill, fmtMoney, fmtMoneyShort */

// ────────────────────────────────────────────────────────────────────────────
// Dashboard view — the Wedding Book
// ────────────────────────────────────────────────────────────────────────────

function DashboardView() {
  return (
    <div className="dash">
      <DashHero />

      <div className="dash__grid">
        <BudgetModule />
        <GuestsModule />
        <TimelineModule />
        <VendorsModule />
        <InspirationModule />
        <SeatingModule />
      </div>

      <DashFoot />
    </div>
  );
}

// ── Hero ────────────────────────────────────────────────────────────────────

function DashHero() {
  const w = RosieData.wedding;
  // Split the day count into two parts so the "days" label sits tightly beside
  const d = w.daysUntil;
  return (
    <header className="hero">
      <div className="hero__topline">
        <span>Wedding Book</span>
        <Ornament kind="asterism" size={9} color="var(--ink-3)" />
        <span>Maintained by Rosie</span>
      </div>

      <div className="hero__body">
        <div className="hero__left">
          <div className="hero__monogram">
            <span className="hero__mono-letter">K</span>
            <span className="hero__mono-amp">&</span>
            <span className="hero__mono-letter">H</span>
          </div>
          <div className="hero__names">
            Kelsie Burns &nbsp;·&nbsp; Hank Harris
          </div>
        </div>

        <div className="hero__center">
          <div className="hero__count">
            <span className="hero__count-n">{d}</span>
            <span className="hero__count-u">days</span>
          </div>
          <div className="hero__date">
            {w.dateFormatted}
          </div>
          <div className="hero__place">
            <em>{w.venue}</em> · {w.location} · {w.ceremonyTime}
          </div>
        </div>

        <div className="hero__right">
          <dl className="hero__facts">
            <div><dt>Dress code</dt><dd>{w.style}</dd></div>
            <div><dt>Colors</dt><dd>{w.colorStory}</dd></div>
            <div><dt>Hashtag</dt><dd>{RosieData.couple.hashtag}</dd></div>
          </dl>
        </div>
      </div>
    </header>
  );
}

// ── Budget ─────────────────────────────────────────────────────────────────

function BudgetModule() {
  const b = RosieData.budget;
  const pct = Math.round((b.spent / b.total) * 100);

  return (
    <Module className="m-budget" title="Budget" subtitle={`${fmtMoney(b.spent)} of ${fmtMoney(b.total)}`} span={2}>
      <div className="budget__topline">
        <Stat value={fmtMoneyShort(b.total - b.spent)} label="Unspent" />
        <Stat value={`${pct}%`} label="Allocated to date" accent="sage" />
        <Stat value={b.categories.filter(c => c.spent > 0).length + ' / ' + b.categories.length}
              label="Categories underway" />
      </div>

      <BudgetBar categories={b.categories} total={b.total} />

      <ul className="budget-list">
        {b.categories.map((c, i) => {
          const pct = Math.round((c.spent / c.allocated) * 100);
          return (
            <li key={i}>
              <span className={`budget-list__swatch budget-list__swatch--${c.color}`} />
              <span className="budget-list__name">{c.name}</span>
              <span className="budget-list__bar">
                <span className={`budget-list__fill budget-list__fill--${c.color}`}
                      style={{ width: `${Math.min(100, pct)}%` }} />
              </span>
              <span className="budget-list__amt">
                {fmtMoneyShort(c.spent)}<span className="budget-list__of"> / {fmtMoneyShort(c.allocated)}</span>
              </span>
            </li>
          );
        })}
      </ul>
    </Module>
  );
}

function BudgetBar({ categories, total }) {
  // Stacked horizontal bar of allocated portions.
  return (
    <div className="budget-bar" aria-label="Allocated budget by category">
      {categories.map((c, i) => {
        const w = (c.allocated / total) * 100;
        return (
          <span key={i}
            className={`budget-bar__seg budget-bar__seg--${c.color}`}
            style={{ width: `${w}%` }}
            title={`${c.name} · ${fmtMoney(c.allocated)}`} />
        );
      })}
    </div>
  );
}

// ── Guests ─────────────────────────────────────────────────────────────────

function GuestsModule() {
  const g = RosieData.wedding.guestCount;
  const totalDeg = 360;
  const confDeg  = (g.confirmed / g.invited) * totalDeg;
  const decDeg   = (g.declined  / g.invited) * totalDeg;
  // Build conic gradient: confirmed (sage) → declined (rose) → pending (cream)
  const conic = `conic-gradient(
    var(--sage)   0deg ${confDeg}deg,
    var(--rose)   ${confDeg}deg ${confDeg + decDeg}deg,
    var(--surface-2) ${confDeg + decDeg}deg 360deg)`;

  return (
    <Module className="m-guests" title="Guests" subtitle={`${g.invited} invited`}>
      <div className="guests__ring">
        <div className="guests__donut" style={{ background: conic }}>
          <div className="guests__donut-hole">
            <div className="guests__donut-n">{g.confirmed}</div>
            <div className="guests__donut-l">confirmed</div>
          </div>
        </div>

        <ul className="guests__legend">
          <li><i style={{ background: 'var(--sage)' }} /><span>Confirmed</span><b>{g.confirmed}</b></li>
          <li><i style={{ background: 'var(--rose)' }} /><span>Declined</span><b>{g.declined}</b></li>
          <li><i style={{ background: 'var(--surface-2)', boxShadow: 'inset 0 0 0 0.5px var(--hairline)' }} /><span>No reply</span><b>{g.pending}</b></li>
        </ul>
      </div>

      <p className="guests__note">
        <Ornament kind="dot" size={10} color="var(--ink-3)" />
        RSVP cards mailed <em>April 12</em>. Reminder note in queue for <em>June 2</em>.
      </p>
    </Module>
  );
}

// ── Timeline ───────────────────────────────────────────────────────────────

function TimelineModule() {
  const items = RosieData.timeline;
  const upcoming = items.filter(i => !i.done).slice(0, 6);
  const recent   = items.filter(i =>  i.done).slice(-3).reverse();

  return (
    <Module className="m-timeline" title="Timeline" subtitle={`${upcoming.length} upcoming`}>
      <SectionLabel>Upcoming</SectionLabel>
      <ul className="timeline">
        {upcoming.map((t, i) => (
          <li key={i} className={`timeline__row ${t.soon ? 'is-soon' : ''}`}>
            <span className="timeline__date">{t.date}</span>
            <span className="timeline__dot" />
            <span className="timeline__label">{t.label}</span>
            {t.soon && <span className="timeline__flag">This week</span>}
          </li>
        ))}
      </ul>

      <SectionLabel style={{ marginTop: 18 }}>Recently done</SectionLabel>
      <ul className="timeline timeline--done">
        {recent.map((t, i) => (
          <li key={i} className="timeline__row">
            <span className="timeline__date">{t.date}</span>
            <span className="timeline__check" aria-hidden="true">
              <svg viewBox="0 0 12 12" width="11" height="11" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
                <path d="M2.5 6.2 5 8.7l4.5-5" />
              </svg>
            </span>
            <span className="timeline__label">{t.label}</span>
          </li>
        ))}
      </ul>
    </Module>
  );
}

// ── Vendors ────────────────────────────────────────────────────────────────

function VendorsModule() {
  const v = RosieData.vendors;
  return (
    <Module className="m-vendors" title="Vendor checklist" subtitle={`${v.filter(x => x.status === 'Booked').length} of ${v.length} booked`} span={2}>
      <table className="vendors">
        <thead>
          <tr>
            <th>Role</th>
            <th>Vendor</th>
            <th>Status</th>
            <th>Due next</th>
            <th className="ta-r">Amount</th>
          </tr>
        </thead>
        <tbody>
          {v.map((row, i) => (
            <tr key={i}>
              <td className="vendors__role">{row.role}</td>
              <td className="vendors__name">
                <div>{row.name}</div>
                <div className="vendors__contact">{row.contact}</div>
              </td>
              <td><StatusPill status={row.status} /></td>
              <td className="vendors__due">{row.dueNext || <span className="vendors__none">—</span>}</td>
              <td className="vendors__amt ta-r">
                {row.amount > 0 ? fmtMoney(row.amount) : <span className="vendors__none">—</span>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </Module>
  );
}

function StatusPill({ status }) {
  const tone = {
    'Booked':      'booked',
    'Deposit':     'deposit',
    'In progress': 'progress',
    'Fittings':    'progress',
    'Trial':       'progress',
    'Inquiry':     'inquiry',
  }[status] || 'neutral';
  return <Pill tone={tone}>{status}</Pill>;
}

// ── Inspiration ────────────────────────────────────────────────────────────

function InspirationModule() {
  const items = RosieData.inspiration;
  const kinds = ['arch','place','candles','bouquet','stationery','silk','dress','bar'];
  return (
    <Module className="m-insp" title="Inspiration" subtitle={`${items.length} saved`}>
      <div className="insp__grid">
        {items.map((it, i) => (
          <figure key={i} className="insp__tile">
            <PaperTile tone={it.color} kind={kinds[i] || 'florals'} />
            <figcaption>{it.label}</figcaption>
          </figure>
        ))}
      </div>
    </Module>
  );
}

// ── Seating ────────────────────────────────────────────────────────────────

function SeatingModule() {
  const s = RosieData.seating;
  return (
    <Module className="m-seating" title="Seating" subtitle={`${s.tables} tables · ${s.seated} seated`}>
      <div className="seating">
        <svg className="seating__map" viewBox="0 0 880 410" preserveAspectRatio="xMidYMid meet">
          {/* dance floor */}
          <rect x="290" y="170" width="250" height="70" rx="2"
                fill="none" stroke="var(--hairline)" strokeDasharray="2 3" />
          <text x="415" y="212" textAnchor="middle" fontFamily="Cormorant Garamond, serif"
                fontStyle="italic" fontSize="14" fill="var(--ink-3)">dance</text>

          {s.layout.map((t) => {
            const r = t.head ? 36 : 30;
            return (
              <g key={t.id} transform={`translate(${t.x}, ${t.y})`}>
                <circle r={r} fill={t.head ? 'var(--rose-tint)' : 'var(--surface)'}
                        stroke={t.head ? 'var(--rose)' : 'var(--hairline)'} strokeWidth="0.8" />
                <text textAnchor="middle" y="2"
                      fontFamily="Cormorant Garamond, serif" fontSize="14" fill="var(--ink)">
                  {t.id}
                </text>
                <text textAnchor="middle" y="16"
                      fontFamily="Cormorant Garamond, serif" fontSize="9" fill="var(--ink-3)"
                      letterSpacing="0.05em">
                  · {t.count} ·
                </text>
              </g>
            );
          })}
        </svg>

        <div className="seating__legend">
          <span><i style={{ background: 'var(--rose-tint)', border: '0.5px solid var(--rose)' }} /> Sweetheart row</span>
          <span><i style={{ background: 'var(--surface)', border: '0.5px solid var(--hairline)' }} /> Guest tables</span>
          <a className="seating__open" href="#" onClick={(e) => e.preventDefault()}>
            Open seating chart →
          </a>
        </div>
      </div>
    </Module>
  );
}

// ── Module shell ──────────────────────────────────────────────────────────

function Module({ title, subtitle, span = 1, className = '', children }) {
  return (
    <section className={`module ${className}`} style={{ gridColumn: `span ${span}` }}>
      <header className="module__head">
        <h3>{title}</h3>
        {subtitle && <span className="module__sub">{subtitle}</span>}
      </header>
      <div className="module__body">
        {children}
      </div>
    </section>
  );
}

function DashFoot() {
  return (
    <footer className="dash__foot">
      <Ornament kind="asterism" size={9} color="var(--ink-3)" />
      <span>Made for <em>Kelsie</em> · Maintained quietly by Rosie · Last updated this morning</span>
      <Ornament kind="asterism" size={9} color="var(--ink-3)" />
    </footer>
  );
}

Object.assign(window, { DashboardView });
