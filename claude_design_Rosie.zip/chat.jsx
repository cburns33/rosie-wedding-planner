/* global React, Ornament, PaperTile, fmtMoney, fmtMoneyShort */

// ────────────────────────────────────────────────────────────────────────────
// Chat view — Rosie & Kelsie
// ────────────────────────────────────────────────────────────────────────────

const CHAT_THREAD = [
  // Day stamp
  { type: 'day', label: 'This morning' },

  { type: 'rosie', text: 'Good morning, Kelsie. Coffee first, then I have three small things for the week — nothing urgent, all good news.' },
  { type: 'rosie', text: 'Saoirse sent over her revised proposal last night. She held the price and added the silk ribbon you wanted on the chuppah.', delay: true },
  { type: 'kelsie', text: 'Oh thank god. I was bracing for a tense email.' },
  { type: 'kelsie', text: 'Can we look at it? I want to make sure the dahlias are still in there.' },

  { type: 'rosie', text: 'Of course. Here it is — same totals, prettier arch.' },
  { type: 'vendor', vendor: {
      name: 'Atelier Saoirse',
      role: 'Floral design',
      blurb: 'Garden roses, café-au-lait dahlias, sage olive branches. Silk ribbon on the chuppah.',
      price: 8200, status: 'Booked', tone: 'sage', kind: 'florals',
      meta: ['Hudson Valley · est. 2011', 'Saoirse Bell — lead designer'],
  }},
  { type: 'kelsie', text: 'Perfect. That ribbon was the whole reason I lost sleep on Tuesday.' },

  { type: 'rosie', text: 'You\'re still well under on florals — here\'s where we land.' },
  { type: 'budget', items: [
    { label: 'Florals & Decor — allocated', value:  18500 },
    { label: 'Saoirse final',               value: -8200 },
    { label: 'Aisle taper candles (held)',  value: -1400 },
    { label: 'Reception greenery (held)',   value: -2900 },
  ], remaining: 6000, remainingLabel: 'Buffer remaining' },

  { type: 'kelsie', text: 'Love a buffer. Put a pin in $1500 of that for the welcome dinner — I keep forgetting we said we\'d do something Friday night.' },
  { type: 'rosie', text: 'Pinned. I\'ll surface a few low-key Friday venues next time we chat.' },

  // Day stamp
  { type: 'day', label: 'Just now' },

  { type: 'rosie', text: 'Second thing — Vivienne at Sable & Vine has Wednesday or Saturday open for the cake tasting. Wednesday would mean less of your weekend, but Hank could only do Saturday.' },
  { type: 'datepicker', options: [
    { date: 'Jun 10', day: 'Wed', time: '2:00 PM', note: 'Kelsie only' },
    { date: 'Jun 13', day: 'Sat', time: '11:30 AM', note: 'With Hank', selected: true },
    { date: 'Jun 17', day: 'Wed', time: '5:30 PM', note: 'Kelsie only' },
  ]},
  { type: 'kelsie', text: 'Saturday with Hank. He\'d sulk for a week if he missed the cake part.' },
  { type: 'rosie', text: 'Booked. I\'ll add it to the calendar and send you both the address Friday.' },

  { type: 'rosie', text: 'And the last thing — I pulled a few cake directions while you were asleep. Tell me which way pulls.' },
  { type: 'moodboard', items: [
    { tone: 'cream', kind: 'cake',       label: 'Three tier, ivory buttercream, sugared roses' },
    { tone: 'rose',  kind: 'cake',       label: 'Naked cake, dahlia crown, single tier' },
    { tone: 'sage',  kind: 'stationery', label: 'Croquembouche tower, gold leaf' },
    { tone: 'blue',  kind: 'cake',       label: 'Pressed-flower fondant, four tier, formal' },
  ]},
  { type: 'kelsie', text: 'The first one. Without question.' },

  { type: 'voicenote', from: 'rosie', duration: '0:34', transcript: 'I had a feeling. Saving the rest for the dessert table — I want to talk to Vivienne about a small croquembouche too.' },

  { type: 'actions', items: ['Save to inspiration', 'Send to Hank', 'Add to checklist'] },
];

const SUGGESTED_REPLIES = [
  'Show alternates for Friday dinner',
  'What\'s next on my checklist?',
  'Draft a note for Hank\'s mom',
];

// ────────────────────────────────────────────────────────────────────────────

function ChatView() {
  const [draft, setDraft] = React.useState('');
  const scrollRef = React.useRef(null);

  React.useEffect(() => {
    // Pin to bottom on mount, the same way a real chat does.
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, []);

  return (
    <div className="chat">
      <ChatHeader />

      <div className="chat__scroll" ref={scrollRef}>
        <div className="chat__column">
          <ChatIntroNote />
          {CHAT_THREAD.map((m, i) => <ChatMessage key={i} m={m} />)}
          <TypingIndicator />
          <div style={{ height: 12 }} />
        </div>
      </div>

      <ChatComposer
        draft={draft}
        setDraft={setDraft}
        suggestions={SUGGESTED_REPLIES}
        onSuggestion={(s) => setDraft(s)}
      />
    </div>
  );
}

function ChatHeader() {
  return (
    <div className="chat__header">
      <div className="chat__header-left">
        <div className="chat__avatar" aria-hidden="true">
          <Ornament kind="rose" size={28} color="var(--rose-ink)" />
        </div>
        <div>
          <div className="chat__title">Rosie</div>
          <div className="chat__sub">
            <span className="chat__pulse" /> Always on · Replies in moments
          </div>
        </div>
      </div>
      <div className="chat__header-right">
        <button className="iconbtn" title="Search this conversation" aria-label="Search">
          <SearchGlyph />
        </button>
        <button className="iconbtn" title="Conversation settings" aria-label="Settings">
          <DotsGlyph />
        </button>
      </div>
    </div>
  );
}

function ChatIntroNote() {
  return (
    <div className="chat__intro">
      <Ornament kind="asterism" size={9} color="var(--ink-3)" />
      <p>
        Encrypted between you and Rosie.
        She remembers everything you tell her — what Hank loves, what your mother dreads,
        the things you don't want on paper. Speak as plainly as you'd like.
      </p>
      <Ornament kind="asterism" size={9} color="var(--ink-3)" />
    </div>
  );
}

function ChatMessage({ m }) {
  if (m.type === 'day') {
    return (
      <div className="day-stamp">
        <span /><em>{m.label}</em><span />
      </div>
    );
  }
  if (m.type === 'rosie' || m.type === 'kelsie') {
    return (
      <div className={`msg msg--${m.type}`}>
        <div className="msg__bubble">
          <p>{m.text}</p>
        </div>
      </div>
    );
  }
  if (m.type === 'vendor') {
    return (
      <div className="msg msg--rosie">
        <VendorCard v={m.vendor} />
      </div>
    );
  }
  if (m.type === 'budget') {
    return (
      <div className="msg msg--rosie">
        <InlineBudget items={m.items} remaining={m.remaining} remainingLabel={m.remainingLabel} />
      </div>
    );
  }
  if (m.type === 'datepicker') {
    return (
      <div className="msg msg--rosie">
        <InlineDatePicker options={m.options} />
      </div>
    );
  }
  if (m.type === 'moodboard') {
    return (
      <div className="msg msg--rosie msg--wide">
        <MoodBoard items={m.items} />
      </div>
    );
  }
  if (m.type === 'voicenote') {
    return (
      <div className={`msg msg--${m.from}`}>
        <VoiceNote duration={m.duration} transcript={m.transcript} />
      </div>
    );
  }
  if (m.type === 'actions') {
    return (
      <div className="msg msg--rosie msg--actions">
        <div className="action-chips">
          {m.items.map((s, i) => (
            <button key={i} className="action-chip">
              <span className="action-chip__plus">+</span> {s}
            </button>
          ))}
        </div>
      </div>
    );
  }
  return null;
}

function VendorCard({ v }) {
  return (
    <div className="vendor-card">
      <div className="vendor-card__media">
        <PaperTile tone={v.tone} kind={v.kind} />
      </div>
      <div className="vendor-card__body">
        <div className="vendor-card__role">{v.role}</div>
        <div className="vendor-card__name">{v.name}</div>
        <p className="vendor-card__blurb">{v.blurb}</p>
        <ul className="vendor-card__meta">
          {v.meta.map((m, i) => <li key={i}>{m}</li>)}
        </ul>
        <div className="vendor-card__foot">
          <div>
            <span className="vendor-card__price-lbl">Final</span>
            <span className="vendor-card__price">{fmtMoney(v.price)}</span>
          </div>
          <span className={`pill pill--booked`}><i className="pill__dot" />{v.status}</span>
        </div>
      </div>
    </div>
  );
}

function InlineBudget({ items, remaining, remainingLabel }) {
  return (
    <div className="inline-budget">
      <div className="inline-budget__head">
        <Ornament kind="dot" size={10} color="var(--sage-ink)" />
        <span>Budget · Florals & Decor</span>
      </div>
      <table>
        <tbody>
          {items.map((it, i) => (
            <tr key={i}>
              <td>{it.label}</td>
              <td className={it.value < 0 ? 'neg' : ''}>
                {(it.value < 0 ? '−' : '') + fmtMoney(Math.abs(it.value))}
              </td>
            </tr>
          ))}
          <tr className="inline-budget__total">
            <td>{remainingLabel}</td>
            <td>{fmtMoney(remaining)}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

function InlineDatePicker({ options }) {
  const [picked, setPicked] = React.useState(() => options.findIndex(o => o.selected));
  return (
    <div className="inline-dates">
      <div className="inline-dates__head">
        <Ornament kind="dot" size={10} color="var(--blue-ink)" />
        <span>Pick a time with Vivienne</span>
      </div>
      <div className="inline-dates__opts">
        {options.map((o, i) => (
          <button key={i}
            className={`inline-date ${picked === i ? 'is-on' : ''}`}
            onClick={() => setPicked(i)}>
            <span className="inline-date__day">{o.day}</span>
            <span className="inline-date__date">{o.date}</span>
            <span className="inline-date__time">{o.time}</span>
            <span className="inline-date__note">{o.note}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function MoodBoard({ items }) {
  return (
    <div className="moodboard">
      <div className="moodboard__head">
        <Ornament kind="dot" size={10} color="var(--rose-ink)" />
        <span>Cake directions · pick one</span>
      </div>
      <div className="moodboard__grid">
        {items.map((it, i) => (
          <figure key={i} className="moodboard__tile">
            <PaperTile tone={it.tone} kind={it.kind} />
            <figcaption>{it.label}</figcaption>
          </figure>
        ))}
      </div>
    </div>
  );
}

function VoiceNote({ duration, transcript }) {
  const [playing, setPlaying] = React.useState(false);
  return (
    <div className="voicenote">
      <button className={`voicenote__play ${playing ? 'is-on' : ''}`}
              onClick={() => setPlaying(p => !p)}
              aria-label={playing ? 'Pause voice note' : 'Play voice note'}>
        {playing ? <PauseGlyph /> : <PlayGlyph />}
      </button>
      <div className="voicenote__body">
        <Waveform playing={playing} />
        <div className="voicenote__meta">
          <span>{duration}</span>
          <span className="voicenote__sep">·</span>
          <em>voice note from Rosie</em>
        </div>
      </div>
    </div>
  );
}

function Waveform({ playing }) {
  // Deterministic, hand-tuned heights so the waveform reads as a real one.
  const heights = [
    6, 10, 14, 9, 16, 22, 18, 13, 8, 14, 20, 26, 22, 16, 11,
    8, 14, 19, 24, 28, 22, 15, 10, 12, 18, 22, 19, 14, 9, 6,
    11, 16, 20, 17, 12, 8, 10, 6, 9, 12, 14, 10, 7,
  ];
  return (
    <div className={`waveform ${playing ? 'is-playing' : ''}`} aria-hidden="true">
      {heights.map((h, i) => (
        <i key={i} style={{ height: h, animationDelay: `${i * 30}ms` }} />
      ))}
    </div>
  );
}

function TypingIndicator() {
  return (
    <div className="msg msg--rosie msg--typing">
      <div className="msg__bubble msg__bubble--typing" aria-label="Rosie is typing">
        <i /><i /><i />
      </div>
    </div>
  );
}

function ChatComposer({ draft, setDraft, suggestions, onSuggestion }) {
  return (
    <div className="composer">
      <div className="composer__suggestions">
        {suggestions.map((s, i) => (
          <button key={i} className="suggest" onClick={() => onSuggestion(s)}>
            {s}
          </button>
        ))}
      </div>
      <div className="composer__field">
        <button className="composer__icon" title="Attach" aria-label="Attach">
          <PlusGlyph />
        </button>
        <input type="text"
          placeholder="Write to Rosie…"
          value={draft}
          onChange={(e) => setDraft(e.target.value)} />
        <button className="composer__icon" title="Voice note" aria-label="Voice note">
          <MicGlyph />
        </button>
        <button className={`composer__send ${draft.trim() ? 'is-on' : ''}`} aria-label="Send">
          <SendGlyph />
        </button>
      </div>
      <div className="composer__foot">
        <span>Press <kbd>↵</kbd> to send · <kbd>⇧</kbd><kbd>↵</kbd> for a line · <kbd>/</kbd> for shortcuts</span>
      </div>
    </div>
  );
}

// ── Tiny glyphs ─────────────────────────────────────────────────────────────
const SearchGlyph = () => (
  <svg viewBox="0 0 20 20" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round">
    <circle cx="9" cy="9" r="5.5" /><path d="M13 13l4 4" />
  </svg>
);
const DotsGlyph = () => (
  <svg viewBox="0 0 20 20" width="16" height="16" fill="currentColor">
    <circle cx="4" cy="10" r="1.3" /><circle cx="10" cy="10" r="1.3" /><circle cx="16" cy="10" r="1.3" />
  </svg>
);
const PlayGlyph = () => (
  <svg viewBox="0 0 16 16" width="12" height="12" fill="currentColor"><path d="M4 3 L13 8 L4 13 Z" /></svg>
);
const PauseGlyph = () => (
  <svg viewBox="0 0 16 16" width="12" height="12" fill="currentColor"><rect x="4" y="3" width="3" height="10" /><rect x="9" y="3" width="3" height="10" /></svg>
);
const PlusGlyph = () => (
  <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round">
    <path d="M8 3v10M3 8h10" />
  </svg>
);
const MicGlyph = () => (
  <svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round">
    <rect x="6" y="2.5" width="4" height="7.5" rx="2" />
    <path d="M4 9a4 4 0 0 0 8 0M8 13v2M5.5 15h5" />
  </svg>
);
const SendGlyph = () => (
  <svg viewBox="0 0 18 18" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2.5 9 15 3 11 15 9 10 2.5 9 Z" />
  </svg>
);

Object.assign(window, { ChatView });
